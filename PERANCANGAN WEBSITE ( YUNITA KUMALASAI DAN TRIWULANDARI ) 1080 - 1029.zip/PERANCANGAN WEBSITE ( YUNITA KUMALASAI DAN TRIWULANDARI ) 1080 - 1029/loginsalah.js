function terimaInput(){
	var username = document.forms['login_salah']['username'].value;
	var password = document.forms['login_salah']['password'].value;

	if (username == "" || password == "" || password != "yks123") {
		alert ("Password anda salah !")
	}
}
