function terimaInput(){
	var tanggal = document.forms['unggah2']['tanggal'].value;

	if (tanggal == "" )  {
		alert ("Mohon masukkan tanggal !")
	}else {
	alert("Foto berhasil diunggah !");
}
}