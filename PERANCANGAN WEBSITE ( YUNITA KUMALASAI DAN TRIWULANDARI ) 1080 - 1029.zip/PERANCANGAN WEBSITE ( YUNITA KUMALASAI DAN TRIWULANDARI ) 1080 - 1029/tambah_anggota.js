function terimaInput(){
	var nama = document.forms['tambah_anggota']['nama'].value;
	var tempatLahir = document.forms['tambah_anggota']['tempatLahir'].value;
	var tanggalLahir = document.forms['tambah_anggota']['tanggalLahir'].value;
	var Kelamin = document.forms['tambah_anggota']['Kelamin'].value;
	var alamat = document.forms['tambah_anggota']['alamat'].value;
	var agama = document.forms['tambah_anggota']['agama'].value;
	var darah = document.forms['tambah_anggota']['darah'].value;
	var status = document.forms['tambah_anggota']['status'].value;
	var ayah = document.forms['tambah_anggota']['ayah'].value;
	var ibu = document.forms['tambah_anggota']['ibu'].value;
	var jumlah = document.forms['tambah_anggota']['jumlah'].value;
	var anak = document.forms['tambah_anggota']['anak'].value;
	var generasi = document.forms['tambah_anggota']['generasi'].value;



	if (nama == "" || tempatLahir == "" || tanggalLahir == "" || Kelamin == "" || 
		alamat == "" || agama == "" || darah == "" || status == "" || ibu == "" ||
		ayah == "" || jumlah == "" || anak == "" || generasi == "")  {
		alert ("Data harus lengkap !")
	}else {
	alert("Data berhasil disimpan");
}
}